Dad Seal Sans — complete corresponding source

Copyright (c) 2026 Ghimist. GNU Affero General Public License v3.0.
Modified 2026-11-03 for calvins-dad. Supplied separately from other fonts.
Upstream: https://github.com/Ghimist/seal-sans at 9372f0813770a605ec5ee068fc48660b231b3427.

upstream.zip is the complete unmodified pinned upstream repository, including
the UFO, FontCreator project, mapping data, original font, scripts and licence.
SealSans-Regular_v1.otf is the exact original build input (also in upstream.zip).
build_seal_sans.py and seal-sans.json are our full modification source/recipe.

Rebuild using Python 3.12+:
  python -m pip install -r requirements.txt
  python build_seal_sans.py --source SealSans-Regular_v1.otf --spec seal-sans.json --output DadSealSans-Regular.otf
  python build_seal_sans.py --source SealSans-Regular_v1.otf --spec seal-sans.json --output DadSealSans-Regular.otf --woff2 rebuilt.woff2

The supplied make_webfont function implements the complete final packaging
steps for this font: subset these same 139 characters, rename to the manifest
family, and encode WOFF2. Its standalone output is tested byte-for-byte against
the app's font. See the source manifest for SHA-256 pins.
No Unicode chart artwork is used as build input.
All selected native cubic curves are translated +340 vertically; advances and
horizontal coordinates retained. Upstream tone UVS, colour, and layout tables
are excluded. No vertical typography is claimed. This is a provisional native
source style; reference topology was compared, not specialist reader approval.

The site exports raster PNGs; it does not embed font programs in exports.
Retain this source download and licence beside any redistributed webfont.
